
const Webcam = require("./webcam.js");


var SpeechRecognition = window.webkitSpeechRecognition;

var recognition = new SpeechRecognition();

recognition.onresult = function(event){

    console.log(event);

    var content = event.results[0][0].transcript;

    document.getElementById("textbox").innerHTML = content;

if (content== "say cheese") {

    console.log("say cheese");

    speak();
}}
function speak() {

    var synth = window.speechSynthesis;

    var speakdata = "Taking Your Selfie In My 5 Seconds";

    var utterthis = new SpeechSynthesisUtterance(speakdata);

    synth.speak(utterthis);

}

Webcam.set({
    width: 360,
    height: 250,
    image_format: 'jpeg',  // image format (may be jpeg or png)
    jpeg_quality: 100      // jpeg image quality from 0 (worst) to 100 
});